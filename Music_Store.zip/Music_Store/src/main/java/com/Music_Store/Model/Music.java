package com.Music_Store.Model;

public class Music
{
    private Integer ID;
    private String Title;
    private String Artist;
    private String Release;
    private String Genre;
    private Integer Tracks;
    private Double Price;


    public Music(Integer ID, String title, String artist, String release, String aGenre, Integer tracks, Double price) {
        this.ID = ID;
        this.Title = title;
        this.Artist = artist;
        this.Release = release;
        this.Genre = aGenre;
        this.Tracks = tracks;
        this.Price = price;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getArtist() {
        return Artist;
    }

    public void setArtist(String artist) {
        Artist = artist;
    }

    public String getRelease() {
        return Release;
    }

    public void setRelease(String release) {
        Release = release;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String genre) {
        this.Genre = genre;
    }

    public Integer getTracks() {
        return Tracks;
    }

    public void setTracks(Integer tracks) {
        Tracks = tracks;
    }

    public Double getPrice() {
        return Price;
    }

    public void setPrice(Double price) {
        Price = price;
    }
}


