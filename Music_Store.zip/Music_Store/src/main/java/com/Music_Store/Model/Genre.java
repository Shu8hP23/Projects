package com.Music_Store.Model;

public enum Genre
{
    ROCK, HIPHOP, RAP, JAZZ, COUNTRY, CLASSICAL;
}
