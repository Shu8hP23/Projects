package com.Music_Store.Service.Impl;

import com.Music_Store.Model.Genre;
import com.Music_Store.Model.Music;
import com.Music_Store.Repo.Impl.MusicRepoImpl;
import com.Music_Store.Repo.MusicRepo;
import com.Music_Store.Service.MusicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.yaml.snakeyaml.events.Event;


import java.util.List;

@Service
public class MusicServiceImpl implements MusicService {
    private final MusicRepo musicRepo;

    public MusicServiceImpl(MusicRepo musicRepo) {
        this.musicRepo = musicRepo;
    }

    @Override
    public List<Music> searchMusic(String term) {
        if (!StringUtils.hasText(term)) {
            throw new IllegalArgumentException("This is an empty field");
        }
        return musicRepo.searchMusic(term);
    }

    @Override
    public List<Music> getMusic() {
        return musicRepo.getMusic();
    }

    @Override
    public void addMusic(String Title, String Artist, String Release, String Genre, Integer Tracks, Double Price) {
        if (!StringUtils.hasText(Title)) {
            throw new IllegalArgumentException("Fill in the field");
        }
        if (!StringUtils.hasText(Artist)) {
            throw new IllegalArgumentException("Fill in the field");
        }
        if (!StringUtils.hasText(Genre)) {
            throw new IllegalArgumentException("Fill in the field");
        }
        if (!StringUtils.hasText(Release)) {
            throw new IllegalArgumentException("Fill in the field");
        }
        if (!StringUtils.hasText(String.valueOf(Tracks))) {
            throw new IllegalArgumentException("Fill in the field");
        }
        if (!StringUtils.hasText(String.valueOf(Price))) {
            throw new IllegalArgumentException("Fill in the field");
        }
        //  try/parse the price
        double musicPrice;
        try {
            musicPrice = Double.valueOf(Price);
        } catch (Exception exception) {
            throw new IllegalArgumentException("unable to parse the game price");
        }
        int track;
        try {
            track = Integer.valueOf(Tracks);
        } catch (Exception exception) {
            throw new IllegalArgumentException("unable to parse the game price");
        }

        int ID = musicRepo.findmaxID();
        var music = new Music(ID + 1, Title, Artist, Release, Genre, track, musicPrice);

        musicRepo.addMusic(music);

    }

    @Override
    public Music getbymusicID(Integer ID) {
        if (ID == null || ID <= 0) {
            throw new IllegalArgumentException("game ID is required");
        }

        return musicRepo.getbymusicId(ID);
    }


    @Override
    public void editMusic(Integer ID, String Title, String Artist, String Release, String Genre, Integer Tracks, Double Price) {

        var music = musicRepo.getbymusicId(ID);
        if (music == null) {
            throw new IllegalArgumentException("Music not found");
        }
        musicRepo.editMusic(music, ID, Title, Artist, Release, Genre, Tracks, Price);
    }

    @Override
    public void deleteMusic(Integer ID) {
        musicRepo.deleteMusic(ID);
    }

}



