package com.Music_Store.Service;

import com.Music_Store.Model.Genre;
import com.Music_Store.Model.Music;

import java.util.List;

public interface MusicService
{
    List<Music> searchMusic(String term);

    List<Music> getMusic();

    void addMusic(String Title, String Artist, String Release, String Genre, Integer Tracks, Double Price);

    Music getbymusicID(Integer ID);

    void deleteMusic(Integer ID);

    void editMusic(Integer ID, String Title, String Artist, String Release, String Genre, Integer Tracks, Double Price);
}
