package com.Music_Store.Repo.Impl;

import com.Music_Store.Model.Music;
import com.Music_Store.Repo.MusicRepo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;

@Repository
public class MusicRepoImpl implements MusicRepo
{
    private List <Music> list;

    public MusicRepoImpl()
    {
        list = new ArrayList<>();
    }

    @Override
    public void addMusic(Music music)
    {
        list.add(music);
    }

    @Override
    public List<Music> searchMusic(String term)
    {
        return list.stream().filter(
                g -> g.getTitle().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT))
        ).collect(Collectors.toList());
    }


    @Override
    public List<Music> getMusic()
    {
        return list;
    }

    @Override
    public Music getbymusicId(Integer ID) {
        var filtered = list.stream().filter(g -> Objects.equals(g.getID(), ID)).collect(Collectors.toList());
        if (filtered.size() > 0) {
            return filtered.get(0);
        }
        throw new IllegalStateException("music not found with ID " + ID);
    }

    @Override
    public int findmaxID()
    {
        var IDList = list.stream().map(Music::getID).collect(Collectors.toList());
        int max = Integer.MIN_VALUE;
        for (int i: IDList) {
            max = Math.max(max, i);
        }

        return max;
    }

    @Override
    public void editMusic(Music music, Integer ID, String Title, String Artist, String Release, String Genre, Integer Tracks, Double Price) {
        music.setID(ID);
        music.setTitle(Title);
        music.setArtist(Artist);
        music.setRelease(Release);
        music.setGenre(Genre);
        music.setTracks(Tracks);
        music.setPrice(Price);
    }

    @Override
    public void deleteMusic(Integer ID)
    {
        this.list = this.list.stream().filter(g -> !Objects.equals(g.getID(), ID)).collect(Collectors.toList());
    }


}
