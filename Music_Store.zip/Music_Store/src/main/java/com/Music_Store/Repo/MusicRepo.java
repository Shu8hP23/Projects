package com.Music_Store.Repo;

import com.Music_Store.Model.Genre;
import com.Music_Store.Model.Music;
import java.util.List;

public interface MusicRepo
{
    List<Music> searchMusic(String term);

    void addMusic(Music music);

    List<Music> getMusic();

    public Music getbymusicId(Integer ID);

    int findmaxID();

    void editMusic(Music music, Integer ID, String Title, String Artist, String Release, String Genre, Integer Tracks, Double Price);

    void deleteMusic(Integer ID);
}
