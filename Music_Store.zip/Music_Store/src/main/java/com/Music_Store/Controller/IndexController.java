package com.Music_Store.Controller;


import com.Music_Store.Model.Music;
import com.Music_Store.Service.MusicService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


import java.util.List;

@Controller
public class IndexController
{
    private final MusicService musicService;

    public IndexController(MusicService musicService)
    {
        this.musicService = musicService;
    }

    @GetMapping("/")
    public String index(Model model)
    {
        List <Music> list =  musicService.getMusic();
        model.addAttribute("list", list);
        return "index";
    }

    @GetMapping("/search")
    public String search(@RequestParam String term, Model model)
    {
        List <Music> list =  musicService.searchMusic(term);
        model.addAttribute("list", list);
        return "index";
    }

    @GetMapping("/success")
    public String success(Model model)
    {
        List<Music> list = musicService.getMusic();
        model.addAttribute("list", list);
        model.addAttribute("successMessage", "Data has been saved");
        return "index";
    }
}

