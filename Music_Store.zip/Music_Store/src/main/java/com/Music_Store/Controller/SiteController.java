package com.Music_Store.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SiteController
{

    @GetMapping("/Career")
    public String Careers()
    {
        return "Career";
    }
    @GetMapping("/About")
    public String About()
    {
        return "About";
    }
    @GetMapping("/Contact")
    public String Contact()
    {
        return "Contact";
    }
    @GetMapping("/Search")
    public String Search()
    {
        return "Search";
    }


}
