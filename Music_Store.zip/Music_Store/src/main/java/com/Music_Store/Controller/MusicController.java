package com.Music_Store.Controller;

import com.Music_Store.Model.Music;
import com.Music_Store.Service.MusicService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class MusicController
{
    private final MusicService musicService;

    public MusicController(MusicService musicService)
    {
        this.musicService = musicService;
    }

    @GetMapping("/music/add")
    public String addMusicview(Model model)
    {
        return "addMusic";
    }


    @PostMapping("/music/add")
    public String addMusicform(Model model, @RequestParam String Title, @RequestParam String Artist,
                               @RequestParam String Release, @RequestParam String Genre, @RequestParam Integer Tracks,
                               @RequestParam Double Price) {
        try{
            musicService.addMusic(Title, Artist, Release, Genre, Tracks, Price);
        } catch (Exception ex) {
            model.addAttribute("ErrorMessage" + ex.getMessage());
            return "addMusic";
        }
        model.addAttribute("SuccessMessage" + " The music has been saved");
        return "addMusic";

    }



    @GetMapping("/music/edit/{ID}")
    public String editMusic(@PathVariable Integer ID, Model model)
    {
        Music music = musicService.getbymusicID(ID);
        model.addAttribute("Title", music.getTitle());
        model.addAttribute("Artist", music.getArtist());
        model.addAttribute("Release", music.getRelease());
        model.addAttribute("Genre", music.getGenre());
        model.addAttribute("Tracks", music.getTracks());
        model.addAttribute("Price", music.getPrice());
        return "editMusic";
    }

    @PostMapping("/music/edit")
    public String editMusicform(@RequestParam Integer ID, @RequestParam String Title, @RequestParam String Artist,
                               @RequestParam String Release, @RequestParam String Genre, @RequestParam Integer Tracks,
                               @RequestParam Double Price, Model model)
    {
        try{
            this.musicService.editMusic(ID, Title, Artist, Release, Genre, Tracks, Price);
        } catch (Exception ex) {
            model.addAttribute("ErrorMessage" + ex.getMessage());

        }

        return "redirect:/success";
    }




    @GetMapping("/music/delete/{ID}")
    public String deleteMusic(@PathVariable Integer ID, Model model)
    {
        try{
            this.musicService.deleteMusic(ID);
        }catch(Exception ex){
            model.addAttribute("Error", ex.getMessage());
        }

        return "redirect:/success";
    }


}
