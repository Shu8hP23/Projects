package com.Music_Store.Bootstrap;
import com.Music_Store.Model.Music;
import com.Music_Store.Repo.MusicRepo;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;


@Component
public class DataBaseLoader implements ApplicationListener <ContextRefreshedEvent>
{
    private final MusicRepo musicRepo;

    public DataBaseLoader(MusicRepo musicRepo)
    {
        this.musicRepo = musicRepo;
    }
    @Override
    public void onApplicationEvent(ContextRefreshedEvent event)
    {
        musicRepo.addMusic(new Music(1, "TPAB", "KDOT", "5/02/2020", "RAP", 10, 59.99));
        musicRepo.addMusic(new Music(2, "CLB", "DRAKE", "10/02/2000", "HIPHOP", 12, 59.99));
        musicRepo.addMusic(new Music(3, "TLOP", "YE", "01/02/2009", "HIPHOP", 23, 59.99 ));
        musicRepo.addMusic(new Music(4, "DONDA", "YE", "12/12/2020", "HIPHOP", 25, 59.99));
    }
}
